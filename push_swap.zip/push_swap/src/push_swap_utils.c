/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcazac <pcazac@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/05 12:19:38 by pcazac            #+#    #+#             */
/*   Updated: 2023/06/05 12:35:41 by pcazac           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/push_swap.h"
// The first element goes at the bottom
void	rotate(t_dlist **stack)
{
	t_dlist	*head;
	t_dlist	*tail;

	head = *stack;
	tail = head;
	while (tail->next)
		tail = tail->next;
	*stack = head->next;
	head->next->previous = NULL;
	head->next = NULL;
	head->previous = tail;
	tail->next = head;
	return ;
}
// The last element goes at the top
void	rrotate(t_dlist **stack)
{
	t_dlist	*head;
	t_dlist	*tail;

	head = *stack;
	tail = head;
	while (tail->next)
		tail = tail->next;
	tail->next = head;
	tail->previous->next = NULL;
	tail->previous = NULL;
	head->previous = tail;
	*stack = tail;
	return ;
}
// Push from stack 1 to stack 2
void	push(t_dlist **stack1, t_dlist **stack2)
{
	t_dlist	*temp1;
	t_dlist	*temp2;
	t_dlist	*temp1_n;
	t_dlist	*temp2_n;

	temp1 = *stack1;
	temp2 = *stack2;
	temp1_n = temp1->next;
	temp2_n = temp2->next;
	temp1_n->previous = temp2;
	temp2_n->previous = temp1;
	temp1->next = temp2_n;
	temp2->next = temp1_n;
	*stack1 = temp2;
	*stack2 = temp1;
	return ;
}
// Swap the first 2 elements
void	swap(t_dlist **stack)
{
	t_dlist	*temp;
	t_dlist	*head;

	head = *stack;
	temp = head->next;
	head->previous = temp;
	temp->previous = NULL;
	head->next = temp->next;
	temp->next = head;
	*stack = temp;
	return ;
}
