/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcazac <pcazac@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/04 22:01:36 by pcazac            #+#    #+#             */
/*   Updated: 2023/06/05 12:17:53 by pcazac           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/push_swap.h"
// The first element goes at the bottom
void	rotate(t_dlist **stack)
{
	t_dlist	*head;
	t_dlist	*tail;

	head = *stack;
	tail = head;
	while (tail->next)
		tail = tail->next;
	*stack = head->next;
	head->next->previous = NULL;
	head->next = NULL;
	head->previous = tail;
	tail->next = head;
	return ;
}
// The last element goes at the top
void	rrotate(t_dlist **stack)
{
	t_dlist	*head;
	t_dlist	*tail;

	head = *stack;
	tail = head;
	while (tail->next)
		tail = tail->next;
	tail->next = head;
	tail->previous->next = NULL;
	tail->previous = NULL;
	head->previous = tail;
	*stack = tail;
	return ;
}
