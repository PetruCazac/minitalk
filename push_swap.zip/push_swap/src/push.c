/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcazac <pcazac@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/04 14:56:25 by pcazac            #+#    #+#             */
/*   Updated: 2023/06/04 18:05:25 by pcazac           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/push_swap.h"

void	push(t_dlist **stack1, t_dlist **stack2)
{
	t_dlist	*temp1;
	t_dlist	*temp2;
	t_dlist	*temp1_n;
	t_dlist	*temp2_n;

	temp1 = *stack1;
	temp2 = *stack2;
	temp1_n = temp1->next;
	temp2_n = temp2->next;
	temp1_n->previous = temp2;
	temp2_n->previous = temp1;
	temp1->next = temp2_n;
	temp2->next = temp1_n;
	*stack1 = temp2;
	*stack2 = temp1;
	return ;
}
