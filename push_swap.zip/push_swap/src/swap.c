/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcazac <pcazac@student.42heilbronn.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/04 18:17:54 by pcazac            #+#    #+#             */
/*   Updated: 2023/06/04 22:01:17 by pcazac           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/push_swap.h"

void	swap(t_dlist **stack)
{
	t_dlist	*temp;
	t_dlist	*head;

	head = *stack;
	temp = head->next;
	head->previous = temp;
	temp->previous = NULL;
	head->next = temp->next;
	temp->next = head;
	*stack = temp;
	return ;
}
