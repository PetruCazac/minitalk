/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcazac <pcazac@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/06 17:02:32 by pcazac            #+#    #+#             */
/*   Updated: 2023/06/06 18:41:36 by pcazac           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/push_swap.h"

void	sort_small(t_dlist **list_a)
{
	int		i;
	int		max;
	t_dlist	**list_b;

	*list_b = NULL;
	if (!sort_check(list_a))
		return ;
	i = count_list(list_a);
	max = i;
	while (i >= 3 && i > 0)
	{
		push(list_a, list_b);
		ft_printf("pb");
		i--;
	}
	sort_3(list_a);
	find
	while ()
	{
		
		if ((*list_b)->number < (*list_a)->number);
	}
}

void	sort_3(t_dlist **list_a)
{
	t_dlist	temp;

	temp = *list_a;
	if (temp  )
}